function calcular(){
    //proceso de transferencia del formulario al javascript
    var n1=document.getElementById("valorc").value;
    var n2=document.getElementById("numc").value;
    var n3=document.getElementById("interes").value;
    //proceso de calculo
    var ValorA=parseFloat(n1)*parseFloat(n3);//para hallar el valor mes a pagar
    var ValorB=(parseFloat(n1)*(1+parseFloat(n2)*parseFloat(n3)));//para hallar el valor total a pagar credito
    //proceso de transferencia del javascript al formulario
    document.getElementById("valora").value=ValorA;
    document.getElementById("valorb").value=ValorB.toFixed(0);

}
function limpiar(){
    document.getElementById("valorc").value=" ";
    document.getElementById("numc").value=" ";
    document.getElementById("interes").value=" ";
}