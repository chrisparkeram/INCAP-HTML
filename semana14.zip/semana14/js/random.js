function apostar(){
    let b=101; //ingresar a ciclo while
    let intentos=0//contador
    var a=Math.round(Math.random()*100);// genera num del 0 al 100
    //ciclo while
    while(a!=b){
        b=parseInt(prompt("Ingrese valor a apostar [0 a 100]"));
        //
        if(b>a){
            alert("EL VALOR ES MAS BAJO")
        }else{
            alert("EL VALOR ES MAS ALTO")
        }
        intentos++;
    }
    //
    document.getElementById("apostado").value=b;
    document.getElementById("resultado").value=a;
    swal("FELICITACIONES USUARIO","HAS ACERTADO EL NUMERO EXITOSAMENTE","success");
    document.getElementById("salida").value="HICISTE... "+intentos+"...intentos";
}
function cancel(){
    document.getElementById("apostado").value=" ";
    document.getElementById("resultado").value=" ";
    document.getElementById("salida").value=" ";
}